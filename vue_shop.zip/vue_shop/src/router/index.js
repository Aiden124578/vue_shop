import Vue from 'vue'
import VueRouter from 'vue-router'
// import Login from '../components/Login.vue'
// import Home from '../components/Home.vue'
// import Welcome from '../components/Welcome.vue'
// import User from '../components/user/Users.vue'
const Login = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Login.vue')
const Home = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Home.vue')
const Welcome = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Welcome.vue')

const User = () => import(/* webpackChunkName: "User_Rights_Roles" */'../components/user/Users.vue')
const Rights = () => import(/* webpackChunkName: "User_Rights_Roles" */'../components/power/Rights.vue')
const Roles = () => import(/* webpackChunkName: "User_Rights_Roles" */'../components/power/Roles.vue')

const Cate = () => import(/* webpackChunkName: "Cate_Params" */'../components/goods/Cate.vue')
const Params = () => import(/* webpackChunkName: "Cate_Params" */'../components/goods/Params.vue')

const Goods = () => import(/* webpackChunkName: "Goods_Add" */'../components/goods/Goods.vue')
const Add = () => import(/* webpackChunkName: "Goods_Add" */'../components/goods/Add.vue')

const Order = () => import(/* webpackChunkName: "Order_Report" */'../components/order/Order.vue')
const Report = () => import(/* webpackChunkName: "Order_Report" */'../components/Report/report.vue')

Vue.use(VueRouter)

  const routes = [
    { path: '/', redirect: '/login' },
    { 
      path: '/login', 
      component: Login,
      meta:{
        title:'登录'
      }
    },
    { 
      path: '/home', 
      component: Home ,
      redirect: '/welcome',
      children:[
        {
          path:'/welcome',
          component:Welcome,
          meta:{
            title:'欢迎'
          }
        },
        {
          path:'/users',
          component:User,
          meta:{
            title:'用户列表'
          }
        },
        {
          path:'/rights',
          component:Rights,
          meta:{
            title:'权限列表'
          }
        },
        {
          path:'/roles',
          component:Roles,
          meta:{
            title:'角色列表'
          }
        },
        {
          path:'/categories',
          component:Cate,
          meta:{
            title:'商品分类'
          }
        },
        {
          path:'/reports',
          component:Report,
          meta:{
            title:'数据报表'
          }
        },
        {
          path:'/goods',
          component:Goods,
          meta:{
            title:'商品列表'
          }
        },
        {
          path:'/params',
          component:Params,
          meta:{
            title:'分类参数'
          }
        },
        {
          path:'/goods/add',
          component:Add,
          meta:{
            title:'添加商品'
          }
        },
        {
          path:'/orders',
          component:Order,
          meta:{
            title:'订单列表'
          }
        }
      ]
    }
]

const router = new VueRouter({
  routes,
  //去掉#，hash
  mode:'history'
})

// 路由权限守卫
router.beforeEach((to, from, next) => {
  // document.title=to.matched[0].meta.title;
  document.title=to.meta.title;
  // console.log(to);
  if (to.path === '/login') return next();
  const tokenStr = window.sessionStorage.getItem('token');
  if (!tokenStr) return next('/login');
  next();
})



export default router
